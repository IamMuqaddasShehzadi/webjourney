<?php
include 'conn.php';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>My Web</title>
</head>
<body>

</body>
</html>